# Jenkins Job Duplicate Analysis Report
**Generated:** December 24, 2024  
**Total Jobs Analyzed:** 309 jobs  
**Potential Cleanup Opportunities:** 25+ jobs

---

## Executive Summary

Analysis of 309 Jenkins jobs revealed significant duplication and consolidation opportunities:

- **37 jobs** in 12 exact duplicate groups (25 can be removed)
- **18 disabled jobs** ready for cleanup
- **63 jobs** without source control (Git)
- **Multiple jobs** with identical commands but different parameters

**Estimated Impact:** Removing duplicates and disabled jobs could reduce job count by ~14% (43 jobs).

---

## 🔴 PRIORITY 1: Exact Duplicates (Immediate Action)

### Group 1: 13 Empty Folder Jobs ⭐ HIGH PRIORITY
**Config Hash:** B59A9DA3F1118112C39E9B67E6DE4B87  
**Jobs:**
1. AA_Team
2. AKS Cluster - Provision - CCV4
3. Azure-Container-Registry
4. cloud-catalog-test
5. eventhub
6. Key Management Tools
7. Key-Vault
8. purview
9. SAS Application Stop -PROD
10. Storage-Account
11. Synapse
12. Synapse Workspace - Provision - CCV4
13. Trash

**Analysis:** These are all empty folders (type: Folder) with no configuration.  
**Recommendation:** Consolidate into organized folder structure. Keep only necessary organizational folders.  
**Action:** Can remove 10-12 of these, keeping 1-2 for valid organization.

---

### Group 2: AML Compute Instance Rebuild (3 duplicates)
**Jobs:**
- AML-Compute-Instance-Rebuild ✅ (Keep - original)
- AML-Compute-Instance-Rebuild-temp1 ❌ (Remove - temp)
- AML-Compute-Instance-Rebuild-temp2 ❌ (Remove - temp)

**Git:** https://github.com/manulife-gft/adl_aml.git  
**Recommendation:** Keep the original, remove temp copies  
**Cleanup Potential:** 2 jobs

---

### Group 3: WFM ADF Publish (3 duplicates)
**Jobs:**
- WFM ADF Publish for Dev, SIT and UAT ✅ (Keep - active, blue status)
- WFM ADF Publish for Dev, SIT and UAT Copy ❌ (Remove - copy)
- WFM ADF Publish for Dev, SIT, UAT ❌ (Remove - duplicate)

**Git:** https://github.com/manulife-gft/adl_aml.git  
**Recommendation:** Keep the active one, remove copies  
**Cleanup Potential:** 2 jobs

---

### Group 4-7: Key Vault & Storage (8 duplicates)

#### Key Vault Secret Creation (2 jobs)
- Key Vault Secret Creation ✅
- Non-prod - Key Vault Secret Creation ❓

**Analysis:** These appear to be environment-specific. Check if parameters can handle both environments.  
**Recommendation:** If both are actively used for different environments, keep both. Otherwise, consolidate with a subscription parameter.

#### Key Vault Secret Role Assignment (2 jobs)
- Key Vault Secret Role Assignment ✅
- Non-prod - Key Vault Secret Role Assignment ❓

**Same analysis as above**

#### Storage Container Creation (2 jobs)
- Storage Account Container Creation ✅
- non-prod storage container creation ❓

#### Storage Container Role Assignment (2 jobs)
- Storage Account Container Role Assignment and Revoke ✅
- non-prod storage container role assignment and revoke ❓

**Total Potential Cleanup:** If environments can be parameterized: 4 jobs

---

### Group 8: ChatMFCGPT Promotion (2 duplicates)
**Jobs:**
- Promotion Python Web App - dev-be-dev-testing (Dev Testing)
- Promotion Python Web App - dev-be-dev-testing (slot1)

**Git:** https://github.com/manulife-gft/ChatMFCGPT.git  
**Status:** Both red (failing)  
**Recommendation:** Fix one, remove the other  
**Cleanup Potential:** 1 job

---

### Group 9-10: Snapshot Restore Jobs (4 duplicates)

#### Step 1 - Create Point in Time (2 jobs)
- Refit-snapshot-restore-step1-create-pointoftime ✅
- Treasury-master-key-poc-snapshot-restore-step1-create-pointoftime ❓

#### Step 2 - Restore from Point in Time (2 jobs)
- Refit-snapshot-restore-step2-restore-from-pointoftime ✅
- treasury-master-key-poc-snapshot-restore-step2-restore-from-pointoftime ❓

**Analysis:** Appear to be project-specific copies  
**Recommendation:** If doing the same thing, consolidate with project parameter  
**Cleanup Potential:** 2 jobs

---

### Group 11: Unity Catalog Jobs (2 duplicates)
**Jobs:**
- UC - Data - (Temporary) Assign Schema Permission (DISABLED)
- UC - Migration - Clone Schema (Red/Failing)

**Recommendation:** Since one is disabled and the other is failing, investigate and fix one, remove the other.  
**Cleanup Potential:** 1 job

---

### Group 12: WFM ADF Trigger (2 duplicates)
**Jobs:**
- WFM ADF Trigger Action for DEV, SIT and UAT ✅ (Active/Blue)
- WFM ADF Trigger Action for DEV, SIT, UAT (Not built)

**Recommendation:** Keep the active one  
**Cleanup Potential:** 1 job

---

## 🟡 PRIORITY 2: Jobs with Identical Scripts

### WebApp Code Deployment (9 jobs with same script)
**Jobs:**
- WebApp - Code Deployment - PRE-PROD - AIW
- WebApp - Code Deployment - PRE-PROD - HR Bot
- WebApp - Code Deployment - PRE-PROD - INFORCEHUB
- WebApp - Code Deployment - PRE-PROD - TPRM
- WebApp - Code Deployment - PRE-PROD - VIRA Project
- WebApp - Code Deployment - PROD - AIW
- WebApp - Code Deployment - PROD - INFORCEHUB
- WebApp - Code Deployment - PROD - TPRM
- WebApp - Code Deployment - PROD - VIRA Project

**Analysis:** All use the same deployment script but for different apps/environments.  
**Recommendation:** Consolidate into ONE job with parameters:
- `environment` (PROD/PRE-PROD)
- `app_name` (AIW/HR Bot/INFORCEHUB/TPRM/VIRA Project)

**Consolidation Potential:** 9 jobs → 1 job = 8 jobs saved

---

### Translator Web Apps (4 jobs)
**Jobs:**
- Web App - translator dev
- Web App - translator PROD
- Web App - translator QA
- Web App - translator UAT

**Recommendation:** Consolidate into one job with environment parameter  
**Consolidation Potential:** 4 jobs → 1 job = 3 jobs saved

---

### MRM/ChatGPT Promotion (4 jobs)
**Jobs:**
- MRM Promotion Python Web App - mrm-dev-be
- MRM Temp - Promotion Python Web App
- Promotion Python Web App - dev-be-dev-testing (Dev Testing)
- Promotion Python Web App - dev-be-dev-testing (slot1)

**Recommendation:** Consolidate with app/slot parameters  
**Consolidation Potential:** 4 jobs → 1 job = 3 jobs saved

---

## 🟠 PRIORITY 3: Disabled Jobs (18 jobs)

**Recommendation:** Review last run date. If not used in 30+ days, DELETE.

Jobs marked "TO BE DELETED" or "old" or "obsolete":
1. ✅ Provision Databricks Compute Cluster - NonProd - TO BE DELETED
2. ✅ Provision Databricks Compute Cluster - PROD - TO BE DELETED
3. ✅ Provision Databricks Workspace-old-toBeDeleteed
4. ✅ Enable MQSQL SQL Audit - OLD
5. ✅ Enable Synapse SQL Audit--obsolete
6. ✅ OLD - AML-Compute-Instance-Provision - OLD

**Cleanup Potential:** At least 6 jobs clearly marked for deletion

---

## 🔵 PRIORITY 4: Git Repository Consolidation

### Most Used Repositories

**78 jobs** use: `https://github.com/manulife-gft/adl_aml.git` (branch: */main)
- This is good - centralized codebase
- Consider organizing jobs into folders by function

**23 jobs** use: `https://github.com/manulife-gft/adl_aml.git` (branch: main)
- **Issue:** Branch reference inconsistency (*/main vs main)
- **Recommendation:** Standardize to */main

---

## 📊 Summary of Recommendations

| Priority | Category | Jobs to Remove/Consolidate | Effort |
|----------|----------|---------------------------|--------|
| 🔴 P1 | Exact Duplicates | 25 jobs | Low |
| 🟡 P2 | Script Consolidation | 14 jobs → 3 jobs | Medium |
| 🟠 P3 | Disabled Jobs | 6-18 jobs | Low |
| 🔵 P4 | Branch Standardization | 0 (cleanup task) | Low |
| **TOTAL** | | **~40-55 jobs** | |

---

## Action Plan

### Week 1: Quick Wins
1. ✅ Delete 6 jobs clearly marked for deletion (disabled + "TO BE DELETED")
2. ✅ Remove 12 empty folder duplicates, keep 1 organized structure
3. ✅ Remove "Copy" and "temp" job variants (5 jobs)

**Week 1 Total:** ~23 jobs removed

### Week 2: Consolidation
1. Consolidate WebApp deployment jobs (9 → 1)
2. Consolidate translator jobs (4 → 1)
3. Review and consolidate Key Vault + Storage jobs

**Week 2 Total:** ~10 jobs consolidated into 2-3 parameterized jobs

### Week 3: Investigation
1. Review remaining 12 disabled jobs
2. Check last run dates
3. Verify snapshot restore job differences (Refit vs Treasury)

---

## Technical Details for Consolidation

### Example: WebApp Deployment Consolidation

**Current:** 9 separate jobs  
**Proposed:** 1 parameterized job

**Parameters needed:**
```
- azure_subscription (choice)
- environment (choice: PROD, PRE-PROD)
- app_name (choice: AIW, HR Bot, INFORCEHUB, TPRM, VIRA Project)
- webapp_resource_group (string)
- webapp_name (string)
```

**Benefits:**
- Single script to maintain
- Easier to update deployment logic
- Consistent behavior across all apps
- Reduced clutter in Jenkins UI

---

## Jobs Without Git (63 jobs)

**Recommendation:** These jobs should be migrated to Git for:
- Version control
- Audit trail
- Disaster recovery
- Team collaboration

**Priority jobs to migrate:**
- Key Vault operations
- Storage operations
- AML operations
- Data Factory operations

---

## Conclusion

**Immediate Cleanup Potential:** 43+ jobs  
**Post-Consolidation:** Could reduce to ~250 jobs (from 309)  
**Reduction:** ~19% fewer jobs to maintain

**Next Steps:**
1. Get approval for Phase 1 deletions (low-risk duplicates)
2. Test consolidated jobs in non-prod
3. Schedule cleanup window for disabled job removal
4. Create migration plan for Git-less jobs

---

*Report generated by AI analysis of Jenkins configuration export*
